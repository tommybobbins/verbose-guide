# LaTeX2HTML 98.2 beta6 (August 14th, 1998)
# Associate internals original text with physical files.


$key = q/table:nllsf03q74/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:specprinc/;
$ref_files{$key} = "$dir".q|node12.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_dabherz/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_childibr/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_carrch2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:70assign/;
$ref_files{$key} = "$dir".q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_yamasih/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_cosbyhf/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:74assign/;
$ref_files{$key} = "$dir".q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_carrh2rev/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_biesken2he2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_carringtonsarre/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_huber/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_zarecashion/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kal/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:unass1/;
$ref_files{$key} = "$dir".q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_herzberg/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:unass2/;
$ref_files{$key} = "$dir".q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/table:unass3/;
$ref_files{$key} = "$dir".q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_hansen/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_carrheh/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_moseleyo2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/equation:machdisk/;
$ref_files{$key} = "$dir".q|node51.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_mosreview/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_hollas/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ivanviva/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_biesken2ne/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:nllsf1370/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:kincomp/;
$ref_files{$key} = "$dir".q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/table:nllsf1374/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:jetsource/;
$ref_files{$key} = "$dir".q|node55.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_zarehbr/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_veseth/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:skimmer/;
$ref_files{$key} = "$dir".q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_saykallyvelmod/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bieskeh2hn2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_herzbergearly/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_maiersep/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_leroyshapeh2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_nishpersonal/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_jmolspecrec/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_moseleyhalfcol/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sarresh/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:lasertim/;
$ref_files{$key} = "$dir".q|node29.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_leroyrkr/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:momprinc/;
$ref_files{$key} = "$dir".q|node12.html|; 
$noresave{$key} = "$nosave";

$key = q/table:nllsf03r74/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_manual/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_cosby/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_daviessih/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sarresih/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_graffshapech/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_saykallylmrrev/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_binning/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_uzer/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_numrec/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_moseleyrev/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_crds/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_oze/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_whitham/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:plotnoz/;
$ref_files{$key} = "$dir".q|node66.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:paritylamborigin/;
$ref_files{$key} = "$dir".q|node39.html|; 
$noresave{$key} = "$nosave";

$key = q/equation:parity/;
$ref_files{$key} = "$dir".q|node39.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kung/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_johnbohp/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_mauricio/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_tad/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:o2s1612f/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_cooks/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_biesken2he/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_tsujiappar/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_carrhene/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kawaguchimagmod/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bus/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:70pipot/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ulrichch/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_williams1/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_saykallylmr/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_moores/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_maierpes/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:bufgas/;
$ref_files{$key} = "$dir".q|node67.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_maierdiacet/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_scoles1/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_scoles2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_graffapj/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_collet/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_cameron/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:nllsf2370/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_woods/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:nllsf2374/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_walmsley/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ulrichper/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_lutz/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bernathbook/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/equation:1dschro/;
$ref_files{$key} = "$dir".q|node46.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bala/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_helmch/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/equation:rad/;
$ref_files{$key} = "$dir".q|node10.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_zajfmanrevsci/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_moseleyfrench/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_carrhd/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_saykallywoods/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_czarny/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_biesken2ne2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:angmomproj/;
$ref_files{$key} = "$dir".q|node38.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:armix/;
$ref_files{$key} = "$dir".q|node67.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_maiercrds/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_drmiller/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:70sigpot/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_lefe/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_leroywidths/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:74sigpot/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_carramsay/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_brzozowski/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_endoftmw/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_zajfman/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/equation:centrifuge/;
$ref_files{$key} = "$dir".q|node42.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kronek/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_hcofoster/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_dyeinfo/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_maiern4/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_moso2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/equation:machno/;
$ref_files{$key} = "$dir".q|node51.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sarreoh/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/equation:jettemp/;
$ref_files{$key} = "$dir".q|node51.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_larss1/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:nllsf03p74/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_boudjarane/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_generalsarre/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_phplus/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:dye/;
$ref_files{$key} = "$dir".q|node30.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_veseth2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_carrhd2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:o2normsource/;
$ref_files{$key} = "$dir".q|node62.html|; 
$noresave{$key} = "$nosave";

$key = q/table:nllsf0370/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:hunda/;
$ref_files{$key} = "$dir".q|node38.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bae/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:hundb/;
$ref_files{$key} = "$dir".q|node38.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:hundc/;
$ref_files{$key} = "$dir".q|node38.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_focsa/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:plotnoz/;
$ref_files{$key} = "$dir".q|node66.html|; 
$noresave{$key} = "$nosave";

$key = q/table:nllsf2474/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:jetbeamcon/;
$ref_files{$key} = "$dir".q|node54.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:shield/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/table:shieldgas/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_childibr2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_wing/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_carrramsay/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ashmanicr/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_coe/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_pjspers1/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sarrech1/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_boudjaranen2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sarrech3/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_cosbyno/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sarrech5/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_harada/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_leroylevel/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sannigrahi/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sarreoh2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ass/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_tsujinear2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_tsu1/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_tsu2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_tsu3/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_daviesheh/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_hfd/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_cosby2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_carrch/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:ionbeam/;
$ref_files{$key} = "$dir".q|node23.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_maiercheminbrit/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_holtlamb/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_cosby4/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/table:74pipot/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_temandsarren2pp/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sarrepqdiff/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_carringtonjet/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_maierrev/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

1;

