# LaTeX2HTML 98.2 beta6 (August 14th, 1998)
# Associate images original text with physical files.


$key = q/pm;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img73.png"
 ALT="$\pm$">|; 

$key = q/Gamma;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="img61.png"
 ALT="$\Gamma$">|; 

$key = q/chi^2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img17.png"
 ALT="$\chi ^{2}$">|; 

$key = q/rmI_N',N'';MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="50" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="img162.png"
 ALT="${\rm I_{N',N''}}$">|; 

$key = q/^1Pi;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img5.png"
 ALT="$^{1}\Pi $">|; 

$key = q/Omega;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="img79.png"
 ALT="$\Omega$">|; 

$key = q/^2Sigma^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img28.png"
 ALT="$^{2}\Sigma^{+}$">|; 

$key = q/displaystyle+(-1)^J~[rm~e~levels];MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="139" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="img88.png"
 ALT="$\displaystyle +(-1)^{J} ~[{\rm ~e~ levels}]$">|; 

$key = q/rmb^4Sigma_g^-leftarrowa^4Pi_u;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="110" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img23.png"
 ALT="${\rm b^{4}\Sigma_{g}^{-}\leftarrow a^{4}\Pi_{u}}$">|; 

$key = q/^3Sigma^-;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img51.png"
 ALT="$^{3}\Sigma^{-}$">|; 

$key = q/_rmel;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img97.png"
 ALT="$_{\rm el}$">|; 

$key = q/resizebox5in!includegraphicsfiguresslashjetsource.eps;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="567" HEIGHT="934" ALIGN="BOTTOM" BORDER="0"
 SRC="img144.png"
 ALT="\resizebox{5in}{!}{\includegraphics{figures/jetsource.eps}}">|; 

$key = q/displaystyleR_2(v)-R_1(v)=frac2betaint^v_vminfracdv^prime[G(v)-G(v^prime)]^frac12equiv2f;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="365" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="img118.png"
 ALT="$\displaystyle R_{2}(v)-R_{1}(v)=\frac{2}{\beta}\int^{v}_{vmin}\frac{dv^{\prime}}{[G(v)-G(v^{\prime})]^{\frac{1}{2}}}\equiv 2f$">|; 

$key = q/rmH_2-HN_2^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="84" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img142.png"
 ALT="${\rm H_{2}-HN_{2}^{+}}$">|; 

$key = q/{displaymath}rmfrac-hbar^22mu~fracd^2Psi_v,J(R)dR^2+V_J(R)Psi_v,J(R)=E_v,JPsi_v,J(R){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="356" HEIGHT="49" BORDER="0"
 SRC="img126.png"
 ALT="\begin{displaymath}
{\rm\frac{-\hbar^{2}}{2\mu}~\frac{d^{2}\Psi_{v,J}(R)}{dR^{2}} + V_{J}(R)\Psi_{v,J}(R) = E_{v,J}\Psi_{v,J}(R)}
\end{displaymath}">|; 

$key = q/pm|Lambda|;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="img84.png"
 ALT="$\pm\vert\Lambda\vert$">|; 

$key = q/deltarmP;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img75.png"
 ALT="$ \delta {\rm P}$">|; 

$key = q/ell;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img26.png"
 ALT="$\ell$">|; 

$key = q/displaystylermC^+(^2P_frac12)+H(^2S)rightarrowCH^+(^1Pi);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="235" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img50.png"
 ALT="$\displaystyle {\rm C^{+}(^{2}P_{\frac{1}{2}}) + H(^{2}S) \rightarrow CH^{+}(^{1}\Pi)}$">|; 

$key = q/_frac12;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img21.png"
 ALT="$_{\frac{1}{2}}$">|; 

$key = q/rmF_4'~(J'=N'-frac32);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="129" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img153.png"
 ALT="${\rm F_{4}' ~(J'=N'-\frac{3}{2})}$">|; 

$key = q/_frac32;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img20.png"
 ALT="$_{\frac{3}{2}}$">|; 

$key = q/^1Sigma;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img22.png"
 ALT="$^{1}\Sigma$">|; 

$key = q/_2^+~rightarrow;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="44" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img157.png"
 ALT="$_{2}^{+} ~\rightarrow$">|; 

$key = q/^2Sigma;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img30.png"
 ALT="$^{2}\Sigma$">|; 

$key = q/pm50;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="35" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img145.png"
 ALT="$\pm 50$">|; 

$key = q/^3Sigma;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img102.png"
 ALT="$^{3}\Sigma$">|; 

$key = q/rmb^4Sigma_g^--a^4Pi_u;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="104" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img49.png"
 ALT="${\rm b^{4}\Sigma_{g}^{-} - a^{4}\Pi_{u}}$">|; 

$key = q/gamma;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img131.png"
 ALT="$\gamma$">|; 

$key = q/ast;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img9.png"
 ALT="$\ast $">|; 

$key = q/_rmn;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img105.png"
 ALT="$_{\rm n}$">|; 

$key = q/displaystyle-(-1)^J~[rm~f~levels];MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="138" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="img89.png"
 ALT="$\displaystyle -(-1)^{J} ~[{\rm ~f~ levels}]$">|; 

$key = q/approx10^5;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="48" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img55.png"
 ALT="$\approx 10^{5}$">|; 

$key = q/pm0.005~;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="63" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img68.png"
 ALT="$\pm0.005~$">|; 

$key = q/_2^+)_rmn;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img134.png"
 ALT="$_{2}^{+})_{\rm n}$">|; 

$key = q/rmGe^+(^2P_begingroup1begingroupover2)+H(^2S_begingroup1begingroupover2);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="156" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img18.png"
 ALT="${\rm Ge^{+}(^{2}P_{\begingroup1\endgroup\over 2}) + H(^{2}S_{{\begingroup1\endgroup\over 2}})}$">|; 

$key = q/resizebox5in!includegraphicsfiguresslashmvsquare.eps;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="570" HEIGHT="479" ALIGN="BOTTOM" BORDER="0"
 SRC="img60.png"
 ALT="\resizebox{5in}{!}{
\includegraphics{figures/mvsquare.eps}}">|; 

$key = q/90^rmo;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img66.png"
 ALT="$90^{\rm o}$">|; 

$key = q/graverme;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img168.png"
 ALT="$\grave{\rm e}$">|; 

$key = q/^prime;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="11" HEIGHT="21" ALIGN="BOTTOM" BORDER="0"
 SRC="img3.png"
 ALT="$^{\prime }$">|; 

$key = q/resizebox5in!includegraphicsfiguresslasho2s1901b.eps;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="576" HEIGHT="792" ALIGN="BOTTOM" BORDER="0"
 SRC="img158.png"
 ALT="\resizebox{5in}{!}{\includegraphics{figures/o2s1901b.eps}}">|; 

$key = q/^4Sigma_u^-;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img31.png"
 ALT="$^{4}\Sigma_{u}^{-}$">|; 

$key = q/Omega=Lambda+Sigma;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="86" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="img76.png"
 ALT="$\Omega = \Lambda +\Sigma$">|; 

$key = q/resizebox5in8inincludegraphicsfiguresslashionbeam.eps;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="569" HEIGHT="927" ALIGN="BOTTOM" BORDER="0"
 SRC="img65.png"
 ALT="\resizebox{5in}{8in}{
\includegraphics{figures/ionbeam.eps}}">|; 

$key = q/displaystylebfS_pm=bfS_xpmibfS_y;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="116" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="img113.png"
 ALT="$\displaystyle {\bf S}_{\pm}={\bf S}_{x}\pm i{\bf S}_{y}$">|; 

$key = q/{displaymath}rmbfT_n=bfH_rmrot+bfH_rmrad{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="131" HEIGHT="30" BORDER="0"
 SRC="img106.png"
 ALT="\begin{displaymath}
{\rm {\bf T}_n = {\bf H}_{\rm rot}+{\bf H}_{\rm rad}}
\end{displaymath}">|; 

$key = q/rmV_rmaccn;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="img72.png"
 ALT="${\rm V}_{\rm accn}$">|; 

$key = q/^3Pi;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img52.png"
 ALT="$^{3}\Pi$">|; 

$key = q/Delta;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="img59.png"
 ALT="$\Delta$">|; 

$key = q/rm^+-He_n;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="66" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img140.png"
 ALT="${\rm _{2}^{+}-He_{n}}$">|; 

$key = q/hatr;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="img99.png"
 ALT="$\hat{r}$">|; 

$key = q/rmN_2^+..He;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="59" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img137.png"
 ALT="${\rm N_2^{+}..He}$">|; 

$key = q/resizebox5in!includegraphicsfiguresslashskimmer.eps;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="574" HEIGHT="795" ALIGN="BOTTOM" BORDER="0"
 SRC="img146.png"
 ALT="\resizebox{5in}{!}{\includegraphics{figures/skimmer.eps}}">|; 

$key = q/resizebox5in!includegraphicsfiguresslashjetbeamcon.eps;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="571" HEIGHT="637" ALIGN="BOTTOM" BORDER="0"
 SRC="img143.png"
 ALT="\resizebox{5in}{!}{\includegraphics{figures/jetbeamcon.eps}}">|; 

$key = q/^1Pi-^1Sigma;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="67" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img1.png"
 ALT="$^{1}\Pi -^{1}\Sigma $">|; 

$key = q/rmH_2C_2^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img40.png"
 ALT="${\rm H_{2}C_{2}^{+}}$">|; 

$key = q/leftarrow;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img7.png"
 ALT="$\leftarrow $">|; 

$key = q/Pi;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="img85.png"
 ALT="$\Pi$">|; 

$key = q/rmDeltaJ=0,pm1;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="90" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="img91.png"
 ALT="${\rm\Delta J=0, \pm 1}$">|; 

$key = q/rmB^2Sigma^+-X^2Sigma^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="114" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img36.png"
 ALT="${\rm B^{2}\Sigma^{+}-X^{2}\Sigma^{+}}$">|; 

$key = q/displaystyleDeltarmJ=pm1,~rmeleftrightarrowe~and~fleftrightarrowf;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="210" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="img93.png"
 ALT="$\displaystyle \Delta {\rm J}=\pm1,~ {\rm e\leftrightarrow e ~and~ f\leftrightarrow f}$">|; 

$key = q/approx10^-6;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="58" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img64.png"
 ALT="$\approx 10^{-6}$">|; 

$key = q/resizebox5in!includegraphicsfiguresslashlasertim.eps;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="568" HEIGHT="1038" ALIGN="BOTTOM" BORDER="0"
 SRC="img69.png"
 ALT="\resizebox{5in}{!}{
\includegraphics{figures/lasertim.eps}}">|; 

$key = q/{displaymath}rmE_v(e)=E_v(f)+q_v(J(J+1))-q_d[J(J+1)]^2+dots{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="373" HEIGHT="31" BORDER="0"
 SRC="img94.png"
 ALT="\begin{displaymath}
{\rm E_{v}(e)= E_{v}(f)+q_{v}(J(J+1))-q_{d}[J(J+1)]^{2}+\dots}
\end{displaymath}">|; 

$key = q/times10^-4;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img160.png"
 ALT="$\times10^{-4}$">|; 

$key = q/rm^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="img44.png"
 ALT="${\rm _{2}H^{+}}$">|; 

$key = q/^2Pi_frac32;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="35" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img45.png"
 ALT="$^{2}\Pi_{\frac{3}{2}}$">|; 

$key = q/rightarrow;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="img4.png"
 ALT="$\rightarrow $">|; 

$key = q/tau;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img62.png"
 ALT="$\tau$">|; 

$key = q/{displaymath}rmnu_t=nu_oleft(frac1-fracvc1+fracvcright)^frac12{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="143" HEIGHT="56" BORDER="0"
 SRC="img57.png"
 ALT="\begin{displaymath}
{\rm\nu_{t} = \nu_{o} \left({\frac {1 - \frac {v}{c}} {1 + \frac {v}{c}}}\right)^\frac{1}{2}}
\end{displaymath}">|; 

$key = q/dagger;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="img11.png"
 ALT="$\dagger $">|; 

$key = q/_rmv,J;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img124.png"
 ALT="$_{\rm v,J}$">|; 

$key = q/displaystylebfJ_pm=bfJ_xpmibfJ_y;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="114" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="img111.png"
 ALT="$\displaystyle {\bf J}_{\pm}={\bf J}_{x}\pm i{\bf J}_{y}$">|; 

$key = q/Lambda>0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="img83.png"
 ALT="$\Lambda &gt; 0$">|; 

$key = q/rmB^2Sigma^+-X^2Sigma;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="103" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img24.png"
 ALT="${\rm B^{2}\Sigma^{+} - X^{2}\Sigma}$">|; 

$key = q/^primermDeltaJ_Fn'Fm''(J'');MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="112" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="img154.png"
 ALT="$^{\prime}{\rm\Delta J_{F{n}'F{m}''}(J'')}$">|; 

$key = q/blacktriangle;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="img15.png"
 ALT="$\blacktriangle $">|; 

$key = q/^1Pi^-;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img87.png"
 ALT="$^{1}\Pi^{-}$">|; 

$key = q/^4Sigma_g^-;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img32.png"
 ALT="$^{4}\Sigma_{g}^{-}$">|; 

$key = q/{displaymath}rmM=fracspeed~of~moleculeslocal~speed~of~sound{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="196" HEIGHT="46" BORDER="0"
 SRC="img132.png"
 ALT="\begin{displaymath}
{\rm M= \frac{speed~of~molecules}{local~speed~of~sound}}
\end{displaymath}">|; 

$key = q/_rmrad;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img103.png"
 ALT="$_{\rm rad}$">|; 

$key = q/{displaymath}rmleft(fracx_MDright)=0.67left(fracP_0P_bright)^frac12{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="164" HEIGHT="55" BORDER="0"
 SRC="img129.png"
 ALT="\begin{displaymath}
{\rm\left(\frac{x_{M}}{D}\right) = 0.67 \left(\frac{P_0}{P_b}\right)^\frac{1}{2}}
\end{displaymath}">|; 

$key = q/1lermnle8;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="78" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img139.png"
 ALT="$1\le{\rm n}\le8$">|; 

$key = q/pi;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img90.png"
 ALT="$\pi$">|; 

$key = q/{displaymath}rmbfH=bfH_el+bfH_rel+bfH_rad+bfH_rot{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="220" HEIGHT="30" BORDER="0"
 SRC="img96.png"
 ALT="\begin{displaymath}
{\rm {\bf H}= {\bf H}_{el} + {\bf H}_{rel} + {\bf H}_{rad} + {\bf H}_{rot}}
\end{displaymath}">|; 

$key = q/rm1ssigma_g;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="39" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="img48.png"
 ALT="${\rm 1s\sigma_{g}}$">|; 

$key = q/rmF_1'~(J'=N'+frac32);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="129" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img150.png"
 ALT="${\rm F_{1}' ~(J'=N'+\frac{3}{2})}$">|; 

$key = q/{displaymath}I_N',N''~alpha~~S_N',N''expleft(frac-B^primeprimekT(N''(N''+1)right){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="431" HEIGHT="55" BORDER="0"
 SRC="img161.png"
 ALT="\begin{displaymath}
I_{N',N''}~\alpha~~ S_{N',N''} exp\left(\frac{-B^{\prime\prime}}{kT}(N''(N''+1)\right)
\end{displaymath}">|; 

$key = q/rmF_3'~(J'=N'-frac12);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="129" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img152.png"
 ALT="${\rm F_{3}' ~(J'=N'-\frac{1}{2})}$">|; 

$key = q/^2Sigma_u^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img37.png"
 ALT="$^{2}\Sigma_{u}^{+}$">|; 

$key = q/^circ;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="22" ALIGN="BOTTOM" BORDER="0"
 SRC="img156.png"
 ALT="$^{\circ}$">|; 

$key = q/resizebox5in!includegraphicsfiguresslashlamborigin.eps;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="566" HEIGHT="723" ALIGN="BOTTOM" BORDER="0"
 SRC="img95.png"
 ALT="\resizebox{5in}{!}{
\includegraphics{figures/lamborigin.eps}}">|; 

$key = q/rmC_6F_6^+.X;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="65" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img27.png"
 ALT="${\rm C_{6}F_{6}^{+}.X}$">|; 

$key = q/_rmrel;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img100.png"
 ALT="$_{\rm rel}$">|; 

$key = q/mu;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img19.png"
 ALT="$\mu $">|; 

$key = q/resizebox5in!includegraphicsfiguresslashspecprinc.eps;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="569" HEIGHT="264" ALIGN="BOTTOM" BORDER="0"
 SRC="img53.png"
 ALT="\resizebox{5in}{!}{
\includegraphics{figures/specprinc.eps}}">|; 

$key = q/includegraphicsfiguresslashhundc.eps;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="333" HEIGHT="453" ALIGN="BOTTOM" BORDER="0"
 SRC="img82.png"
 ALT="\includegraphics{figures/hundc.eps}">|; 

$key = q/sqrtfrac2muhbar^2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="57" ALIGN="MIDDLE" BORDER="0"
 SRC="img120.png"
 ALT="$\sqrt{\frac{2\mu}{\hbar^{2}}}$">|; 

$key = q/_rmJ;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img125.png"
 ALT="$_{\rm J}$">|; 

$key = q/rm^16O_2^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="44" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img149.png"
 ALT="${\rm ^{16}O_{2}^{+}}$">|; 

$key = q/rmS_N',N'';MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="img163.png"
 ALT="${\rm S_{N',N''}}$">|; 

$key = q/approx10^6;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="48" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img67.png"
 ALT="$\approx 10^{6}$">|; 

$key = q/{displaymath}rmE_rot(R)=frachbar^22muR^2left[J(J+1)-Omega^2right]{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="244" HEIGHT="48" BORDER="0"
 SRC="img109.png"
 ALT="\begin{displaymath}
{\rm E_{rot}(R)= \frac{\hbar^{2}}{2\mu R^{2}}\left[J(J+1)- \Omega^{2} \right]}
\end{displaymath}">|; 

$key = q/_rmeff;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img117.png"
 ALT="$_{\rm eff}$">|; 

$key = q/rmB^2Sigma_u^+~-~X^2Sigma_g^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="126" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="img133.png"
 ALT="${\rm B^{2}\Sigma_{u}^{+}~-~X^{2}\Sigma}_{g}^{+}$">|; 

$key = q/rm^2Sigma^+_u-X^2Sigma_g^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="102" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img33.png"
 ALT="${\rm ^{2}\Sigma^{+}_{u}-X^{2}\Sigma_{g}^{+}}$">|; 

$key = q/rmA^2Pi_u-X^2Sigma^+_g;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="112" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img41.png"
 ALT="${\rm A^{2}\Pi_{u}-X^{2}\Sigma^{+}_{g}}$">|; 

$key = q/rmDeltaJ;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img155.png"
 ALT="${\rm\Delta J}$">|; 

$key = q/1lermnle3;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="78" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img141.png"
 ALT="$1\le{\rm n}\le 3 $">|; 

$key = q/_rmrot;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img104.png"
 ALT="$_{\rm rot}$">|; 

$key = q/displaystyleR_2(v)=sqrtf^2+fracfg+f;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="176" HEIGHT="79" ALIGN="MIDDLE" BORDER="0"
 SRC="img122.png"
 ALT="$\displaystyle R_{2}(v)=\sqrt{f^{2}+\frac{f}{g}} + f$">|; 

$key = q/nu_2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="img43.png"
 ALT="$\nu_{2}$">|; 

$key = q/nu_t;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="img56.png"
 ALT="$\nu_{t}$">|; 

$key = q/rmO(^3P_2)+O^+(^4S^0);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="143" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img147.png"
 ALT="${\rm O(^{3}P_{2}) + O^{+}({^4}S^{0})}$">|; 

$key = q/rmF_2'~(J'=N'+frac12);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="129" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img151.png"
 ALT="${\rm F_{2}' ~(J'=N'+\frac{1}{2})}$">|; 

$key = q/^1Delta;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="26" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img46.png"
 ALT="$^{1}\Delta$">|; 

$key = q/approx;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img25.png"
 ALT="$\approx$">|; 

$key = q/{displaymath}Gamma(rmcm^-1)approxfrac5.3times10^-12tau(s){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="171" HEIGHT="49" BORDER="0"
 SRC="img63.png"
 ALT="\begin{displaymath}
\Gamma({\rm cm}^{-1}) \approx \frac{5.3\times10^{-12}}{\tau(s)}
\end{displaymath}">|; 

$key = q/Pi^f;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="26" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="img2.png"
 ALT="$\Pi ^{f}$">|; 

$key = q/_rmb;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img127.png"
 ALT="$_{\rm b}$">|; 

$key = q/includegraphicsfiguresslashhundb.eps;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="259" HEIGHT="444" ALIGN="BOTTOM" BORDER="0"
 SRC="img81.png"
 ALT="\includegraphics{figures/hundb.eps}">|; 

$key = q/bullet;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img14.png"
 ALT="$\bullet $">|; 

$key = q/^2Pi;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img29.png"
 ALT="$^{2}\Pi$">|; 

$key = q/rm^14N_2^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img34.png"
 ALT="${\rm ^{14}N_{2}^{+}}$">|; 

$key = q/_rmM;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img128.png"
 ALT="$_{\rm M}$">|; 

$key = q/rm^15N_2^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img35.png"
 ALT="${\rm ^{15}N_{2}^{+}}$">|; 

$key = q/blacksquare;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="img13.png"
 ALT="$\blacksquare $">|; 

$key = q/displaystyleDeltarmJ=0,rm~eleftrightarrowf;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="115" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="img92.png"
 ALT="$\displaystyle \Delta {\rm J}=0, {\rm ~e\leftrightarrow f}$">|; 

$key = q/{displaymath}V_inner(R)=A+Be^-fracCR{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="175" HEIGHT="31" BORDER="0"
 SRC="img123.png"
 ALT="\begin{displaymath}
V_{inner}(R)= A + Be^{-\frac{C}{R}}
\end{displaymath}">|; 

$key = q/^2Sigma_g^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img38.png"
 ALT="$^{2}\Sigma_{g}^{+}$">|; 

$key = q/^1Pi^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img86.png"
 ALT="$^{1}\Pi^{+}$">|; 

$key = q/{displaymath}rmT(eV)=fracm_216m_3timesleft(fracDeltaErmEright)^2timesrmV_rmaccn{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="412" HEIGHT="55" BORDER="0"
 SRC="img70.png"
 ALT="\begin{displaymath}
{ \rm T(eV)=\frac{m_2}{16m_{3}}\times\left({\frac{\Delta E}{ \rm E}}\right)^{2}\times {\rm V}_{\rm accn}}
\end{displaymath}">|; 

$key = q/nu_o;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="img58.png"
 ALT="$ \nu_{o}$">|; 

$key = q/{displaymath}rmbfH'_rot(R)=frachbar^22muR^2left[(L_+S_--L_-S_+)-(J_+L_-+J_-L_+)-(J_+S_-+J_-S_+)right]{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="528" HEIGHT="48" BORDER="0"
 SRC="img110.png"
 ALT="\begin{displaymath}
{\rm {\bf H}'_{rot}(R)= \frac{\hbar^{2}}{2\mu R^{2}}\left[(L_+S_--L_-S_+)-(J_+L_-+J_-L_+)-(J_+S_-+J_-S_+)\right]}
\end{displaymath}">|; 

$key = q/displaystyleR_1(v)=sqrtf^2+fracfg-f;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="176" HEIGHT="79" ALIGN="MIDDLE" BORDER="0"
 SRC="img121.png"
 ALT="$\displaystyle R_{1}(v)=\sqrt{f^{2}+\frac{f}{g}} - f$">|; 

$key = q/^primeprime;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="21" ALIGN="BOTTOM" BORDER="0"
 SRC="img12.png"
 ALT="$^{\prime \prime }$">|; 

$key = q/rmH_3^+(H_2)_n;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img136.png"
 ALT="${\rm H_{3}^{+}(H_{2})_{n}}$">|; 

$key = q/geq;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img115.png"
 ALT="$\geq$">|; 

$key = q/^4Pi_frac52,frac32,frac12,-frac12;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="86" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img148.png"
 ALT="$^{4}\Pi_{\frac{5}{2},\frac{3}{2},\frac{1}{2},-\frac{1}{2}}$">|; 

$key = q/Lambda;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="img77.png"
 ALT="$\Lambda$">|; 

$key = q/_1^+rightarrow;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img71.png"
 ALT="$_{1}^{+}\rightarrow$">|; 

$key = q/_rme;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="11" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="img10.png"
 ALT="$_{\rm e}$">|; 

$key = q/times10^-5;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img135.png"
 ALT="$\times10^{-5}$">|; 

$key = q/includegraphicsfiguresslashhunda.eps;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="478" HEIGHT="495" ALIGN="BOTTOM" BORDER="0"
 SRC="img80.png"
 ALT="\includegraphics{figures/hunda.eps}">|; 

$key = q/^1Sigma^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img6.png"
 ALT="$^{1}\Sigma ^{+}$">|; 

$key = q/resizebox5in!includegraphicsfiguresslasho2s1612f.epsi;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="576" HEIGHT="792" ALIGN="BOTTOM" BORDER="0"
 SRC="img164.png"
 ALT="\resizebox{5in}{!}{\includegraphics{figures/o2s1612f.epsi}}">|; 

$key = q/^prime_rmrot;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="img114.png"
 ALT="$^{\prime}_{\rm rot}$">|; 

$key = q/{displaymath}rmV_eff(R)=V_el(R)+frachbar^22muR^2left[J(J+1)-Omega^2right]{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="314" HEIGHT="48" BORDER="0"
 SRC="img116.png"
 ALT="\begin{displaymath}
{\rm V_{eff}(R) = V_{el}(R) + \frac{\hbar^{2}}{2\mu R^{2}}\left[J(J+1)-\Omega^{2} \right]}
\end{displaymath}">|; 

$key = q/Sigma;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="img78.png"
 ALT="$\Sigma$">|; 

$key = q/displaystylefrac1R_1(v)-frac1R_2(v)=frac12pibetaint^v_vminfracB_v^'dv^prime[G(v)-G(v^prime)]^frac12equiv2g;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="391" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="img119.png"
 ALT="$\displaystyle \frac{1}{R_{1}(v)}-\frac{1}{R_{2}(v)}=\frac{1}{ 2\pi \beta}\int^{v}_{vmin}\frac{ B_{v^{'}}dv^{\prime}}{[G(v)-G(v^{\prime})]^{\frac{1}{2}}}\equiv 2g$">|; 

$key = q/rm^+-Ne_n;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="66" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img138.png"
 ALT="${\rm _{2}^{+}-Ne_{n}}$">|; 

$key = q/beta;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="img16.png"
 ALT="$\beta $">|; 

$key = q/{displaymath}rmbfH_el=-frachbar^22msum_nnabla_n^2+V(hatr,R){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="204" HEIGHT="55" BORDER="0"
 SRC="img98.png"
 ALT="\begin{displaymath}
{\rm {\bf H}_{el}= -\frac{\hbar^{2}}{2m}\sum_{n}\nabla_{n}^{2}+ V(\hat{r},R)}
\end{displaymath}">|; 

$key = q/resizebox5in!includegraphicsfiguresslashmomprinc.eps;LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="571" HEIGHT="286" ALIGN="BOTTOM" BORDER="0"
 SRC="img54.png"
 ALT="\resizebox{5in}{!}{
\includegraphics{figures/momprinc.eps}}">|; 

$key = q/{displaymath}rmbfH_rad=-frachbar2muR^2.fracpartialpartialR.left(R^2.fracpartialpartialRright){displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="387" HEIGHT="55" BORDER="0"
 SRC="img107.png"
 ALT="\begin{displaymath}
{\rm {\bf H}_{rad}= - \frac{\hbar}{2\mu R^{2}} . \frac{\partial}{\partial R}.\left(R^{2}.\frac{\partial}{\partial R}\right)}
\end{displaymath}">|; 

$key = q/fracPdeltarmP;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="img74.png"
 ALT="$\frac{P}{\delta {\rm P}}$">|; 

$key = q/times10^-8;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img159.png"
 ALT="$\times10^{-8}$">|; 

$key = q/rmA^2Pi_u,frac32-X^2Pi_g,frac32;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="136" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img39.png"
 ALT="${\rm A^{2}\Pi_{u,\frac{3}{2}}-X^{2}\Pi_{g,\frac{3}{2}}}$">|; 

$key = q/displaystylebfL_pm=bfL_xpmibfL_y;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="119" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="img112.png"
 ALT="$\displaystyle {\bf L}_{\pm}={\bf L}_{x}\pm i{\bf L}_{y}$">|; 

$key = q/sigma;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img8.png"
 ALT="$\sigma $">|; 

$key = q/rm^2Pi_u-X^2Sigma_g^+;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="99" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img47.png"
 ALT="${\rm ^{2}\Pi_{u}-X^{2}\Sigma_{g}^{+}}$">|; 

$key = q/nu_3;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="img42.png"
 ALT="$\nu_{3}$">|; 

$key = q/{displaymath}rmfracTT_0=left(1+left(fracgamma-12right)M^2right)^-1{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="388" HEIGHT="55" BORDER="0"
 SRC="img130.png"
 ALT="\begin{displaymath}
{\rm\frac{T}{T_0}=\left(1+\left(\frac{\gamma-1}{2}\right)M^{2}\right)^{-1}}
\end{displaymath}">|; 

$key = q/{displaymath}rmbfH_rel=bfH_so=sum_nA_nbfunderlineL_n.underlineS_n{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="377" HEIGHT="51" BORDER="0"
 SRC="img101.png"
 ALT="\begin{displaymath}
{\rm {\bf H}_{rel}= {\bf H}_{so} = \sum_{n}A_{n}{\bf\underline {L}_{n}.\underline{S}_{n}}}
\end{displaymath}">|; 

$key = q/{displaymath}rmbfH_rot=-frachbar2muR^2.left[underlinebfJ-underlinebfL-underlinebfSright]^2{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="210" HEIGHT="46" BORDER="0"
 SRC="img108.png"
 ALT="\begin{displaymath}
{\rm {\bf H}_{rot}= - \frac{\hbar}{2\mu R^{2}}.\left[\underline{\bf J}-\underline{\bf L}-\underline{\bf S}\right]^{2}}
\end{displaymath}">|; 

1;

